﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework2
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Computer theMSI = new Computer
            {
                model = "MSI",
                price = 2307,
                screenSize = 14.1f,
                numberOfProcessors = 1
            };
            theMSI.turnOn();
            theMSI.turnOff();
            theMSI.addingProcessor();
            Console.WriteLine("====================================");
            Computer theMac = new Computer
            {
                model = "MacBook",
                price = 990,
                screenSize = 13.3f,
                numberOfProcessors = 2
            };
            theMac.turnOn();
            theMac.turnOff();
            theMac.addingProcessor();
            Console.WriteLine("====================================");
            Computer theLenovo = new Computer
            {
                model = "Lenovo",
                price = 200,
                screenSize = 11.6f,
                numberOfProcessors = 3
            };
            theLenovo.turnOn();
            theLenovo.turnOff();
            theLenovo.addingProcessor();
            Console.WriteLine("====================================");
            Console.WriteLine(theMSI.ToString());
        }
    }
}
