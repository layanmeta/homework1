﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework2
{
    [DebuggerDisplay("{model}, price = {price * 3.67} shekels")]
  
    class Computer
    { 


        public string model;
        public int price;
        public int numberOfProcessors;
        public float screenSize;
        public bool isTurnOn = false;

        public int tellMeThePrice()
        {
            return price;
        }
        public float tellMeScreenSize()
        {
            return screenSize;
        }
        public void turnOn()
        {
            Console.WriteLine($"The {model} computer is turning on ");
            isTurnOn = true;
        }
        public void turnOff()
        {
            Console.WriteLine($"the {model} computer is turning off");
            isTurnOn = false;
        }
        public void addingProcessor()
        {
            Console.WriteLine($"the number of processors is {numberOfProcessors + 1}");
        }

        public override string ToString()
        {
            return $"class computer, model {model} with price of {price} dollars and screen size {screenSize}, processor is {numberOfProcessors + 1}";
        }
    }

}
