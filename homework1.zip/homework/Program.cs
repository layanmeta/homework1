﻿using System;

namespace homework
{
    

    class Program
    {
        static void Main(string[] args)
        {
            computer theMSI = new computer
            {
                model = "MSI",
                price = 8000,
                screenSize = 14.1f,
                numberOfProcessors = 1
            };
            theMSI.turnOn();
            theMSI.turnOff();
            theMSI.addingProcessor();
            Console.WriteLine("====================================");
            computer theMac = new computer
            {
                model = "MacBook",
                price = 4360,
                screenSize = 13.3f,
                numberOfProcessors = 2
            };
            theMac.turnOn();
            theMac.turnOff();
            theMac.addingProcessor();
            Console.WriteLine("====================================");
            computer theLenovo = new computer
            {
                model = "Lenovo",
                price = 690,
                screenSize = 11.6f,
                numberOfProcessors = 3
            };
            theLenovo.turnOn();
            theLenovo.turnOff();
            theLenovo.addingProcessor();
            Console.WriteLine("====================================");
            Console.WriteLine(theMSI);

        }
    }
}
