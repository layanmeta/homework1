﻿using System;

namespace homework
{
    // no need
    internal class debuggerDisplayerAttribute : Attribute
    {
    }
}