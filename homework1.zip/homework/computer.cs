﻿using System;
using System.Collections.Generic;
using System.Text;

namespace homework
{
    //[DebuggerDisplayer("{model}")]

    class computer
    {
        public string model;
        public int price;
        public int numberOfProcessors;
        public float screenSize;
        public bool isTurnOn = false;

        public int tellMeThePrice()
        {
            return price;
        }
        public float tellMeScreenSize()
        {
            return screenSize;
        }
        public void turnOn()
        {
            Console.WriteLine($"The {model} computer is turning on ");
            isTurnOn = true;
        }
        public void turnOff()
        {
            Console.WriteLine($"the {model} computer is turning off");
            isTurnOn = false;
        }
        public void addingProcessor()
        {
            Console.WriteLine($"the number of processors is {numberOfProcessors + 1}");
        }

        public override string ToString()
        {
            return $"class computer, model {model} with price of {price} and screen size {screenSize}, processor is {numberOfProcessors + 1}";
        }
    }

}
